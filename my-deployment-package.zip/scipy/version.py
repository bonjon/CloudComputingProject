
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.5.4'
version = '1.5.4'
full_version = '1.5.4'
git_revision = '19acfed431060aafaa963f7e530c95e70cd4b85c'
release = True

if not release:
    version = full_version
